import { Button } from "../components/ui/button";
import { Card, CardContent } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { useState } from "react";

const profiles = [
  {
    name: "Sofia",
    location: "Mallorca",
    age: 26,
    languages: ["Deutsch", "Englisch"],
    image: "/girls/sofia.jpg",
    tagline: "Sonnenanbeterin mit Stil und Humor"
  },
  {
    name: "Chloé",
    location: "Paris",
    age: 24,
    languages: ["Französisch", "Englisch"],
    image: "/girls/chloe.jpg",
    tagline: "Deine charmante Begleiterin für Kunst & Kultur"
  },
  {
    name: "Alina",
    location: "Dubai",
    age: 29,
    languages: ["Russisch", "Englisch"],
    image: "/girls/alina.jpg",
    tagline: "Luxus, Lifestyle und gute Gespräche"
  }
];

export default function Home() {
  const [destination, setDestination] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [showResults, setShowResults] = useState(false);

  const handleSearch = () => {
    setShowResults(true);
  };

  return (
    <div style={{ fontFamily: 'sans-serif', padding: 20 }}>
      <h1 style={{ fontSize: 32, fontWeight: 'bold' }}>Rent a Holiday Girlfriend</h1>
      <p style={{ marginTop: 10, marginBottom: 20 }}>Finde charmante Urlaubsfreundinnen für unvergessliche Reisen.</p>

      <div style={{ marginBottom: 20 }}>
        <Label>Reiseziel</Label>
        <Input value={destination} onChange={e => setDestination(e.target.value)} placeholder="z. B. Mallorca" />
        <Label>Startdatum</Label>
        <Input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} />
        <Label>Enddatum</Label>
        <Input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} />
        <Button onClick={handleSearch} style={{ marginTop: 10 }}>Begleitung finden</Button>
      </div>

      {showResults && (
        <div style={{ display: 'grid', gap: 20 }}>
          {profiles.map((profile, i) => (
            <Card key={i}>
              <CardContent>
                <h2>{profile.name}, {profile.age}</h2>
                <p>📍 {profile.location}</p>
                <p><i>{profile.tagline}</i></p>
                <p>Sprachen: {profile.languages.join(", ")}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
